let generatedEmail = null;
Cypress.Commands.add('generateEmail', () => {
  if (generatedEmail) {
    return generatedEmail;
  }
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
  const length = 10; // Specify the desired length of the username    
  let username = "";
  for (let i = 0; i < length; i++) {
    username += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  const domain = 'gmail.com';
  generatedEmail = `${username}@${domain}`;
  return generatedEmail;
});
import 'cypress-file-upload';