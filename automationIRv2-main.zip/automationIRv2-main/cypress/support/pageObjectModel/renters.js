import renterSelectors from "./renterSelectors"
const elements = new  renterSelectors()
let email = null;
export class renters{
    websiteVisit(){
        cy.visit('/')
    }
    signup(){
        elements.signupPage.signUpURL
        cy.generateEmail().then((generatedEmail) => {
          email = generatedEmail;
          elements.signupPage.emailField.type(email)
        });
        elements.signupPage.passwordField().type('C0mplexpass@');
        elements.signupPage.signupButton()
        elements.signupPage.signupBtn().click()
    }
    login(){
        elements.loginPage.loginURL();
        elements.loginPage.emailField().type(email)
        elements.loginPage.passwordField().type('C0mplexpass@')
        elements.loginPage.loginButton()
        elements.loginPage.loginBtn().click()
        cy.wait(2000)
    }
    readTerms(){
        elements.readTermPage.readTermsBtn().click()
        elements.readTermPage.acceptBtn().click()
    }
    selectProperty(){
        elements.selectPropertyPage.applicationProperty().click()
        elements.selectPropertyPage.selectPropertyApp.click()
        elements.selectPropertyPage.continueWithProperty.click()
    }
    rentalCriteria(){
        elements.rentalCriteriaPage.reviewPage().click()
        elements.rentalCriteriaPage.openDocument().click()
        elements.rentalCriteriaPage.readDocument().click()
        elements.rentalCriteriaPage.gotItBtn().click()
    }
    navigation(){
        elements.navigationPage.navigationDropdown().click()
    }
    address(){
        elements.addressPage.addressFromNavigationDropdown().click()
        elements.addressPage.presentFromDate().click()
        elements.addressPage.rentBtn().click()
        elements.addressPage.ownerFullName()
        elements.addressPage.rent
        elements.addressPage.phoneNumber()
        elements.addressPage.emailAddress()
        elements.addressPage.gotItBtn().click()
        elements.addressPage.searchAddress()
        elements.addressPage.pickAddress().click()
        elements.addressPage.fromDate()
        elements.addressPage.toDate()
        elements.addressPage.notRentBtn().click()
        elements.addressPage.looksGoodBtn().click()
    }
    employment(){
        elements.employmentPage.employedBtn().click()
        elements.employmentPage.companyName().click()
        elements.employmentPage.role()
        elements.employmentPage.empFromDate()
        elements.employmentPage.monthlyGrossIncome()
        elements.employmentPage.supervisorName()
        elements.employmentPage.supervisorPhoneNumber()
        elements.employmentPage.supervisorEmailAddress()
        elements.employmentPage.looksGoodBtn().click()
        elements.employmentPage.notHaveBankAccountBtn()
    } 
}
export const rentersObj = new renters()