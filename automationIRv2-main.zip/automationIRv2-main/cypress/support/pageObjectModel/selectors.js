class Selectors{
   
    signupPage = {
        signUpURL: () => cy.visit('https://staging.internalrent.com/signup'),
        emailField: () => cy.get('[id="Email Address"]'),
        passwordField: () => cy.get('#Password'),
        signupButton: () => cy.get('.Signup_createBtn__So7UZ'),
        signupBtn: () => contains('Create account')
      };
     
    
   loginPage = {

        loginURL: () =>  cy.visit('https://staging.internalrent.com/login'),
        emailField: () => cy.get('[id="Email Address"]'),
        passwordField: () => cy.get('#Password'),
        loginButton: () => cy.get('[type="submit"]'),
        loginBtn: () => contains('Log in')
      };

    AgentPrivProfile = {
        housingProviderCategory: () => cy.get('.css-hlgwow'),
        option: () => cy.get('.css-qr46ko').find('[class=" css-1ir0vnz-option"]').first(),
        firstName: () => cy.get('[id="First Name"]'),
        lastName: () => cy.get('[placeholder="Last Name"]'),
        mailSearch: () => cy.get('[placeholder="Type to search"]'),
        mailSearchOpt: () => cy.get('.PlacesAutoCompleteComponent_suggestionOptions__1Xb3f'),
        phoneNumberField: () => cy.get('.react-tel-input'),
        saveContinueButton: () =>  cy.get('[type="submit"]'),
        saveContinueBtn: () => contains('Save & Continue'),
    };

    addProperty = {
        navProperty:() => cy.get('.PopoverDropdown_linkContainer__0nQ7B').contains('Properties').click(),
        btnAddProperty:() => cy.get('.Button_irBtn__Ozjsb').contains('+ Add Property').click(),
        selectPropertyType: () => cy.get('.css-1xc3v61-indicatorContainer').click(),
        selectPropertyTypeClick: () => cy.get('#react-select-7-option-0').click(),
        address:() => cy.get('[placeholder="Type to search"]').type('123').wait(2000),
        addressClick :()=>cy.get('.PlacesAutoCompleteComponent_suggestionOptions__1Xb3f').first().click(),
        unit:() => cy.get('[id="Unit # (Recommended if applicable)"]').type('unit'),
        availableDate: () => cy.get('.CustomDatePicker_removeBorder__jXrAo').click(),
        propertyName :() => cy.get('[id="Property Name or Title (Optional)"]').type('Property Automation'),
        sharedLivingSpace:() => cy.get('[name="sharedLivingSpace"]').check(),
        hideAddress: () =>cy.get('[name="hideAddress"]').check(),
        nextBtn:() => cy.get('.Button_irBtn__Ozjsb').contains('Next').click(),
        rentAmount:() => cy.get('#Rent').type('1000'),
        depositAmount:() => cy.get('[name="depositAmount"]').type('1000'),
        squareFeet:() => cy.get('[id="Square Feet (Optional)"]').type('11'), 
        beds:() => cy.get('.ReactSelect_defaultSelectChild__4ueTN').first().click(),
        bedsCount:()=>cy.get('.css-qr46ko').find('[class="FormikSelectField_customSelect__TJRKO"]').contains('2').click(),
        baths:() => cy.get('.ReactSelect_defaultSelectChild__4ueTN').eq(0).click(),
        bedsCount:()=> cy.get('.css-1jlyntg-option').contains('2').click(),
        leaseDuration:() => cy.get('.ReactSelect_defaultSelectChild__4ueTN').eq(0).click(),
        leaseDurationOption:()=>cy.get('.FormikSelectField_customSelect__TJRKO').contains('Monthly').click(),
        laundry:() => cy.get('.ReactSelect_defaultSelectChild__4ueTN').first().click(),
        laundryOptions:()=>cy.get('.css-qr46ko').find('.css-1jlyntg-option').first().contains('In unit').click(),
        parking:() => cy.get('.ReactSelect_defaultSelectChild__4ueTN').last().click(),
        pets:() => cy.get('.css-qr46ko').find('.css-1jlyntg-option').first().click(),
        petsClick:()=>cy.get('[name="allowedPets"]').check(),
        additionalFeatures:() => cy.get('[name="customFeature"]').click().type('washer'),
        additionFeaturesFirst:()=>cy.get('[class="AmenitiesFeature_tagContainer__woWBb"]').first().contains('Washer').click(),
        additionFeaturesClick:()=>cy.get('[class="AddProperty_crossIconContainer__2rUBb"]').click(),
        description:() => cy.get('.ql-container').click().type('testing{selectall}'),
        descriptionClick:()=>cy.get('.ql-bold').click(),
        uploadImage:() =>cy.get('[class="dropzone Dropzone_noFilesDropzone__X6o4O"]')
            .find('[type="button"]').contains('Select from computer').click().attachFile(filePath),
        tourLinks:() => cy.get('.formik-field').first().type('https://www.atlasbayvr.com/some-name'),
        tourLinksName:()=>cy.get('.formik-field').last().type('name'),
        btnPublish:() =>
        cy.get('[type="button"]').contains('Publish').click()
    }

    pagination = {
        visitPropertyPage:() =>  cy.visit('https://staging.internalrent.com/Properties?option=Published&layout=list'),
        selectPropertyLimitDropdown:() => cy.get("div[class='Pagination_perPageCol__ph30H col-lg-4 col-md-3 col-sm-12'] div[class='ReactSelect_container__j54LR']")
        .click(),
        selectPageLimit5Btn:() => cy.get('#react-select-6-option-0').click(),
        selectPageLimit10Btn:() => cy.get('#react-select-6-option-1').click(),
        selectPageLimit15Btn: () => cy.get('#react-select-6-option-2').click(),
        selectPageLimit20Btn: () => cy.get('#react-select-6-option-3').click(),
        nextPageBtn:() => cy.get('[data-testid="next-page"]'),
        prevPageBtn:() => cy.get("a[class='page-link']"),
    }
}
export default Selectors  