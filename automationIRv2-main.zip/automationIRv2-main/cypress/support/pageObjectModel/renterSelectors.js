class renterSelectors{
    signupPage = {
        signUpURL: () => cy.visit('https://staging.internalrent.com/signup?r=cmVudGVy'),
        emailField: () => cy.get('[id="Email Address"]'),
        passwordField: () => cy.get('#Password'),
        signupButton: () => cy.get('.Signup_createBtn__So7UZ'),
        signupBtn: () => contains('Create account')
      };
   loginPage = {
        loginURL: () =>  cy.visit('https://staging.internalrent.com/login'),
        emailField: () => cy.get('[id="Email Address"]'),
        passwordField: () => cy.get('#Password'),
        loginButton: () => cy.get('[type="submit"]'),
        loginBtn: () => contains('Log in')
      };
    readTermPage = {
        readTermsBtn:() => cy.get('[type="button"]').contains('Read terms'),
        acceptBtn:()=>  cy.get('[type="button"]').contains('I accept')
    };
    selectPropertyPage = {
        applicationProperty :()=> cy.get('[type="button"]').contains('Select a property to start your application'),
        selectPropertyApp :()=> cy.get('[type="button"]').contains('Select a property to start your application'),
        continueWithProperty :()=>  cy.get('[type="button"]').contains('Continue with this property')
    };
   rentalCriteriaPage = {
    reviewPage :()=> cy.get('[type="button"]').contains('Review rental criteria'),
    openDocument :()=> cy.get('[type="button"]').contains('*Open full document here'),
    readDocument:()=> cy.get('[type="button"]').contains('I have read the Rental Criteria'),
    gotItBtn :()=> cy.get('[type="button"]').contains("Got it, let's get started!")
   }
   navigationPage = {
    navigationDropdown :() =>cy.get('.css-hlgwow')
   }
   addressPage ={
    addressFromNavigationDropdown :()=> cy.get('.css-1ir0vnz-option').eq(3),
    presentFromDate:()=> cy.get('[placeholder="MM DD YYYY"]'),
    rentBtn:()=> cy.get('[type="button"]').contains('I rent'),
    ownerFullName:()=> cy.get('[placeholder="Full Name"]').type('khadija zahid'),
    rent:()=> cy.get('[name="renterAddress.contactRent"]').type('1000'), 
    phoneNumber:()=> cy.get('[placeholder="(000) 000-0000"]').type('7626235265'),
    emailAddress:()=> cy.get('[name="renterAddress.contactEmailAddress"]').type('khadija@gmail.com'),
    gotItBtn:()=> cy.get('[type="button"]').contains('Got it, next!'),
    searchAddress:()=> cy.get('[placeholder="Type to search"]').type('123').wait(5000),
    pickAddress:()=> cy.get('.PlacesAutoCompleteComponent_suggestionOptions__1Xb3f').first(),
    fromDate:()=>  cy.get('[placeholder="MM DD YYYY"]').first().type('02032009'),
    toDate:()=> cy.get('[placeholder="MM DD YYYY"]').last().type('02032010'),
    notRentBtn:()=> cy.get('[type="button"]').contains('I do not rent'),
    looksGoodBtn:()=> cy.get('[type="button"]').contains("Looks good!")
   }
   employmentPage ={
    employedBtn: ()=> cy.get('[type="button"]').first().contains('Employed'),
    companyName: ()=> cy.get('[placeholder="Company Name"]').type('Intellirent'),
    role: ()=>  cy.get('[placeholder="Your role"]').type('Project Manager'),
    empFromDate:()=> cy.get('[placeholder="MM DD YYYY"]').type('09092009'),
    monthlyGrossIncome :()=> cy.get('[name="monthlyGrossIncome"]').type('10000'),
    supervisorName:()=> cy.get('[name="supervisorName"]').type('Eric'),
    supervisorPhoneNumber:()=>  cy.get('[placeholder="(000) 000-0000"]').type('8673653343'),
    supervisorEmailAddress:()=> cy.get('[name="supervisorEmailAddress"]').type('kzahid@gmail.com'),
    looksGoodBtn:()=>  cy.get('[type="submit"]').contains('Looks good!'),
    notHaveBankAccountBtn:()=>  cy.get('[type="button"]').contains('I do not have a bank')
   }
}
export default renterSelectors  