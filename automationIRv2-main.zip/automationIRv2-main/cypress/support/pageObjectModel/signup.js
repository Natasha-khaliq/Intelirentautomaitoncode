let email = null;
export class signup{ 
    agentSignupVisit(){
         cy.visit('https://staging.internalrent.com/signup');
    }
    getEmailField(){
        cy.generateEmail().then((generatedEmail) => {
            email = generatedEmail;
            cy.get('[id="Email Address"]').type(email);
          });
        }
    getPasswordField(){
         cy.get('#Password').type('C0mplexpass@');
    }
    getCreateAccountButton(){
        cy.get('.Signup_createBtn__So7UZ').contains('Create account').click();
    }
    signup(){
        this.agentSignupVisit()
        this.getEmailField()
        this.getPasswordField()
        this.getCreateAccountButton()
    }
}
export const signupObj = new signup() 