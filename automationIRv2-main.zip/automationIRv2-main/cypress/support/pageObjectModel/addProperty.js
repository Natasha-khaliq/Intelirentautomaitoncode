export class addProperty{
    websiteVisit(){
        cy.visit('/')
    }
    login(){
        cy.visit('https://staging.internalrent.com/login');
            cy.get('[id="Email Address"]').type('rqadir@myintellirent.com');
            cy.get('#Password').type('password@#1234');
            cy.get('[type="submit"]').contains('Log in').click();
            cy.wait(2000);
    }
    navProperty(){
        // select Properties option from navbar
        cy.get('.PopoverDropdown_linkContainer__0nQ7B').contains('Properties').click()
    }
    btnAddProperty(){
        cy.get('.PropertyIndex_applicantButton__-NZDG').contains('+ Add Property').click()
    }
    selectPropertyType(){
        cy.get('.css-hlgwow').find('.css-19bb58m').click()
        cy.get('.css-1ay5h3f-menu').find('.css-1ir0vnz-option').eq(1).click()
    }
    address(){
        cy.get('[placeholder="Type to search"]').type('123').wait(2000)
        cy.get('.PlacesAutoCompleteComponent_suggestionOptions__1Xb3f').first().click()
    }
    unit(){
        cy.get('[id="Unit # (Recommended if applicable)"]').type('unit')
    }
    availableDate(){
        cy.get('.CustomDatePicker_removeBorder__jXrAo').click()
    }
    propertyName(){
        cy.get('[id="Property Name or Title (Optional)"]').type('Property Automation')
    }
    sharedLivingSpace(){
        cy.get('[name="sharedLivingSpace"]').check()
    }
    hideAddress(){
        cy.get('[name="hideAddress"]').check()
    }
   nextBtn() {
        cy.get('.Button_irBtn__Ozjsb').contains('Next').click()
    }
    rentAmount(){
        cy.get('#Rent').type('1000')
    }
    depositAmount(){
        cy.get('[name="depositAmount"]').type('1000')
    }
    squareFeet(){
        cy.get('[id="Square Feet (Optional)"]').type('11')
    }
    beds(){
        cy.get('.ReactSelect_defaultSelectChild__4ueTN').first().click()
        cy.get('.css-qr46ko').find('[class="FormikSelectField_customSelect__TJRKO"]').contains('2').click()
    }
    baths(){
        cy.get('.ReactSelect_defaultSelectChild__4ueTN').eq(0).click()
        cy.get('#react-select-9-option-2').contains('2').click()
    }
    leaseDuration(){
        cy.get('.ReactSelect_defaultSelectChild__4ueTN').eq(0).click()
        cy.get('.FormikSelectField_customSelect__TJRKO').contains('Monthly').click()
    }
    laundry(){
        cy.get('.ReactSelect_defaultSelectChild__4ueTN').first().click()
        //cy.get('.css-qr46ko').find('#react-select-12-option-1').contains('In unit').click()
        cy.get("div[class='css-qr46ko']").find('#react-select-10-option-0').click()
    }

    parking(){
        cy.get('.ReactSelect_defaultSelectChild__4ueTN').last().click()
        cy.get('#react-select-14-option-3').click()
    }
    pets(){
        cy.get('.AddProperty_amenities__bvJSH').find('.Checkbox_container__JuGX6').eq(1).click()
        cy.get('[name="allowedPets"]').check()
    }
    additionalFeatures(){
        cy.get('[name="customFeature"]').click().type('washer')
        cy.get('[class="AmenitiesFeature_tagContainer__woWBb"]').first().contains('Washer').click()
        cy.get('[class="AddProperty_crossIconContainer__2rUBb"]').click()
    }
    description(){
        cy.get('.ql-container').click().type('testing{selectall}')
        cy.get('.ql-bold').click()
    }
    uploadImage(){
        const filePath = '/Users/dev/Desktop/automationIRv2/cypress/fixtures/dev.jpeg'
        cy.get('[class="dropzone Dropzone_noFilesDropzone__X6o4O"]')
            .find('[type="button"]').contains('Select from computer').click().attachFile(filePath);
    }
    tourLinks(){
        cy.get('.formik-field').first().type('https://www.atlasbayvr.com/some-name')
        cy.get('.formik-field').last().type('name')
    }
    btnPublish(){
        cy.get('[type="button"]').contains('Publish').click()
    }
    addProperty(){
        this.navProperty()
        this.btnAddProperty()
        this.selectPropertyType()
        this.address()
        this.unit()
        this.availableDate()
        this.propertyName()
        this.sharedLivingSpace()
        this.hideAddress()
        this.nextBtn()
        this.rentAmount()
        this.depositAmount()
        this.squareFeet()
        this.beds()
        this.baths()
        this.leaseDuration()
        this.nextBtn()
        this.laundry()
        this.parking()
        this.pets()
        this.additionalFeatures()
        this.nextBtn()
        this.description()
        this.nextBtn()
        this.uploadImage()
        this.tourLinks()
        this.btnPublish()
    }
}
export const propertyObj = new addProperty()