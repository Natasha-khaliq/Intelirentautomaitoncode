import Selectors from "./Selectors"
const elements = new  Selectors()
let email = null;
export class agentPrivateProfile{   
   signup(){
        elements.signupPage.signUpURL
        cy.generateEmail().then((generatedEmail) => {
        email = generatedEmail
        elements.signupPage.emailField.type(email)
        });
        elements.signupPage.passwordField().type('C0mplexpass@');
        elements.signupPage.signupButton()
        elements.signupPage.signupBtn().click()
        cy.contains('Private Profile')
   }
   login(){
        elements.loginPage.loginURL();
        elements.loginPage.emailField().type(email)
        elements.loginPage.passwordField().type('C0mplexpass@')
        elements.loginPage.loginButton()
        elements.loginPage.loginBtn().click()
   }
   housingCategory() {
        elements.AgentPrivProfile.housingProviderCategory().first().click();
        elements.AgentPrivProfile.option().click();
}
   firstName(){
        elements.AgentPrivProfile.firstName.type('First')
   }
   lastName(){
        elements.AgentPrivProfile.lastName.type('Last')
   }
   address(){
        elements.AgentPrivProfile.mailSearch.type('123').wait(5000)
        elements.AgentPrivProfile.mailSearchOpt.first().click()
   }
   phoneNumber(){
        elements.AgentPrivProfile.phoneNumberField.type('2345678999')
        cy.wait(5000)
   }
   saveContinueBtn(){
        elements.AgentPrivProfile.saveContinueButton
        elements.AgentPrivProfile.saveContinueBtn.click();
   }
}
export const agentPrivateProfileObj = new agentPrivateProfile() 