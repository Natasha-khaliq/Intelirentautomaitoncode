import Selectors from './selectors'
const selectors = new Selectors();

export class checkPagination {

    setPageLimit5(){
        const itemSelector = ("div[class='PropertyIndex_propertyTitle__+7E7U']");
        const itemsPerPage = 5; 
        const expectedUrl = "https://staging.internalrent.com/Properties?option=Published&layout=list&perPage=5&page=1";

        selectors.pagination.visitPropertyPage
        selectors.pagination.selectPropertyLimitDropdown
        cy.log('Clicked the button successfully!')
        selectors.pagination.selectPageLimit5Btn
        cy.url().should("eq", expectedUrl);
        cy.get(itemSelector).should("have.length.lte", itemsPerPage);
    }

    setPagelimit10(){
        const itemSelector = ("div[class='PropertyIndex_propertyTitle__+7E7U']");
        const itemsPerPage = 10; 
        const expectedUrl = "https://staging.internalrent.com/Properties?option=Published&layout=list&perPage=10&page=1";
        
        selectors.pagination.visitPropertyPage
        selectors.pagination.selectPropertyLimitDropdown
        cy.log('Clicked the button successfully!')
        selectors.pagination.selectPageLimit10Btn
        cy.url().should("eq", expectedUrl);
        cy.get(itemSelector).should("have.length.lte", itemsPerPage);
    }

    setPagelimit15(){
        const itemSelector = ("div[class='PropertyIndex_propertyTitle__+7E7U']");
        const itemsPerPage = 15; 
        const expectedUrl = "https://staging.internalrent.com/Properties?option=Published&layout=list&perPage=15&page=1";
        
        selectors.pagination.visitPropertyPage
        selectors.pagination.selectPropertyLimitDropdown
        cy.log('Clicked the button successfully!')
        selectors.pagination.selectPageLimit15Btn
        cy.url().should("eq", expectedUrl);
        cy.get(itemSelector).should("have.length.lte", itemsPerPage);
    }

    setPagelimit20(){
        const itemSelector = ("div[class='PropertyIndex_propertyTitle__+7E7U']");
        const itemsPerPage = 20; 
        const expectedUrl = "https://staging.internalrent.com/Properties?option=Published&layout=list&perPage=20&page=1";
        
        selectors.pagination.visitPropertyPage
        selectors.pagination.selectPropertyLimitDropdown
        cy.log('Clicked the button successfully!')
        selectors.pagination.selectPageLimit20Btn
        cy.url().should("eq", expectedUrl);
        cy.get(itemSelector).should("have.length.lte", itemsPerPage);
    }

    nextEnabled(){
        const itemSelector = ("div[class='PropertyIndex_propertyTitle__+7E7U']");
        const itemsPerPage = 5; 
        const expectedUrl = "https://staging.internalrent.com/Properties?option=Published&layout=list&perPage=5&page=2";

        selectors.pagination.visitPropertyPage
        selectors.pagination.selectPropertyLimitDropdown
        cy.log('Clicked the button successfully!')
        selectors.pagination.selectPageLimit5Btn

        const totalProducts = 12;
        const productsPerPage = 5;
        const totalPages = Math.ceil(totalProducts / productsPerPage);
        if (totalPages > 1) {
            selectors.pagination.nextPageBtn.should("not.be.disabled");
            selectors.pagination.nextPageBtn.click()
            cy.url().should("eq", expectedUrl)
        } else {
            selectors.pagination.nextPageBtn.should("not.be.enabled");
        } 
    }

    nextDisabled(){
        const itemSelector = ("div[class='PropertyIndex_propertyTitle__+7E7U']");
        const itemsPerPage = 20;
        const expectedUrl = "https://staging.internalrent.com/Properties?option=Published&layout=list&perPage=5&page=1";

        selectors.pagination.visitPropertyPage
        selectors.pagination.selectPropertyLimitDropdown
        cy.log('Clicked the button successfully!')
        selectors.pagination.selectPageLimit20Btn

        const totalProducts = 12;
        const productsPerPage = 20;
        const totalPages = Math.ceil(totalProducts / productsPerPage);
        if (totalPages > 1) {
            selectors.pagination.nextPageBtn.should("not.be.disabled")
        } else {
            selectors.pagination.nextPageBtn.should("not.be.enabled")
        } 
    }

    prevEnabled(){
        const itemSelector = ("div[class='PropertyIndex_propertyTitle__+7E7U']");
        const itemsPerPage = 5; 
        selectors.pagination.visitPropertyPage
        selectors.pagination.selectPropertyLimitDropdown
        cy.log('Clicked the button successfully!')
        selectors.pagination.selectPageLimit5Btn

        const totalProducts = 12;
        const productsPerPage = 5;
        const totalPages = Math.ceil(totalProducts / productsPerPage);
        if (totalPages > 1) {
            selectors.pagination.prevPageBtn.should("not.be.disabled");
        } else {
            selectors.pagination.prevPageBtn.should("not.be.enabled");
        } 
    }

    prevDisabled(){
        const itemSelector = ("div[class='PropertyIndex_propertyTitle__+7E7U']");
        const itemsPerPage = 20; 
        const expectedUrl = "https://staging.internalrent.com/Properties?option=Published&layout=list&perPage=5&page=1";

        selectors.pagination.visitPropertyPage
        selectors.pagination.selectPropertyLimitDropdown
        cy.log('Clicked the button successfully!')
        selectors.pagination.selectPageLimit20Btn

        const totalProducts = 12;
        const productsPerPage = 20;
        const totalPages = Math.ceil(totalProducts / productsPerPage);
        if (totalPages > 1) {
        selectors.pagination.prevPageBtn.should("not.be.disabled");
        } else {
        selectors.pagination.prevPageBtn.should("not.be.enabled");
        } 
    }
}

export const pagination = new checkPagination()
