const {agentPrivateProfileObj} = require("../support/PageObjectModel/agentPrivateProfile")
describe('Agent Private Profile', () => {
    it('Signup', () => {
        agentPrivateProfileObj.signup()
    });
    it('Login', () => {
        agentPrivateProfileObj.login()
    });
    it('Agent Private Profile', () => {
        agentPrivateProfileObj.housingCategory()
        agentPrivateProfileObj.firstName()
        agentPrivateProfileObj.lastName()
        agentPrivateProfileObj.address()
        agentPrivateProfileObj.phoneNumber()
        agentPrivateProfileObj.saveContinueBtn()
    });
})