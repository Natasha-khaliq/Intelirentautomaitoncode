describe("add Property",()=>{
  before("login",()=>{
          cy.visit('https://staging.internalrent.com/login');
          cy.get('[id="Email Address"]').type('rqadir@myintellirent.com');
          cy.get('#Password').type('password@#1234');
          cy.get('[type="submit"]').contains('Log in').click();
          cy.wait(2000);
  })
  it("Add Property",()=>{
      cy.get('.PopoverDropdown_linkContainer__0nQ7B').contains('Properties').click()
      cy.get('.Button_irBtn__Ozjsb').contains('+ Add Property').click()
      //cy.get('#react-select-6-placeholder').contains('Select property type').click()
      cy.get('.css-1xc3v61-indicatorContainer').click()
      cy.get('#react-select-7-option-0').click()
      cy.get('[placeholder="Type to search"]').type('123').wait(2000)
      cy.get('.PlacesAutoCompleteComponent_suggestionOptions__1Xb3f').first().click()
      cy.get('[id="Unit # (Recommended if applicable)"]').type('unit')
      cy.get('.CustomDatePicker_removeBorder__jXrAo').click()
      cy.get('[id="Property Name or Title (Optional)"]').type('Property Automation')
      cy.get('[name="sharedLivingSpace"]').check()
      cy.get('[name="hideAddress"]').check()
      cy.get('.Button_irBtn__Ozjsb').contains('Next').click()
      cy.get('#Rent').type('1000')
      cy.get('[name="depositAmount"]').type('1000')
      cy.get('[id="Square Feet (Optional)"]').type('11')
      cy.get('.ReactSelect_defaultSelectChild__4ueTN').first().click()
      cy.get('.css-qr46ko').find('[class="FormikSelectField_customSelect__TJRKO"]').contains('2').click()
      cy.get('.ReactSelect_defaultSelectChild__4ueTN').eq(0).click()
      cy.get('.css-1jlyntg-option').contains('2').click()
      cy.get('.ReactSelect_defaultSelectChild__4ueTN').eq(0).click()
      cy.get('.FormikSelectField_customSelect__TJRKO').contains('Monthly').click()
     // cy.get('.ReactSelect_defaultSelectChild__4ueTN').eq(1).click()
      cy.get('.Button_irBtn__Ozjsb').contains('Next').click()
      cy.get('.ReactSelect_defaultSelectChild__4ueTN').first().click()
      cy.get('.css-qr46ko').find('.css-1jlyntg-option').first().contains('In unit').click()
      cy.get('.ReactSelect_defaultSelectChild__4ueTN').last().click()
      cy.get('.css-qr46ko').find('.css-1jlyntg-option').first().click()
      cy.get('[name="allowedPets"]').check()
      cy.get('[name="customFeature"]').click().type('washer')
      cy.get('[class="AmenitiesFeature_tagContainer__woWBb"]').first().contains('Washer').click()
      cy.get('[class="AddProperty_crossIconContainer__2rUBb"]').click()
      cy.get('.Button_irBtn__Ozjsb').contains('Next').click()
      cy.get('.ql-container').click().type('testing{selectall}')
      cy.get('.ql-bold').click()
      cy.get('.Button_irBtn__Ozjsb').contains('Next').click()  
      cy.get('.formik-field').first().type('https://www.atlasbayvr.com/some-name')
      cy.get('.formik-field').last().type('name')
      const filePath = 'dev.jpeg'
      cy.get('[class="dropzone Dropzone_noFilesDropzone__X6o4O"]')
          .find('[type="button"]').contains('Select from computer').click().attachFile(filePath);
      cy.get('[type="button"]').contains('Publish').click()

  })
})