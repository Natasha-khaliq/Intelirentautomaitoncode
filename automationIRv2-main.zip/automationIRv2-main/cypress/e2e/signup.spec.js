describe('Test Suite for Agent', () => {
    let email = null;
    it('Signup', () => {
      cy.visit('https://staging.internalrent.com/signup');
      cy.generateEmail().then((generatedEmail) => {
        email = generatedEmail;
        cy.get('[id="Email Address"]').type(email);
      });
      cy.get('#Password').type('C0mplexpass@');
      cy.get('.Signup_createBtn__So7UZ').contains('Create account').click();
      cy.contains('Private Profile')
    });
})