const {signupObj} = require("../support/PageObjectModel/signUp")
describe('signup', () => {
    it('Signup', () => {
      signupObj.signup()
    });
})