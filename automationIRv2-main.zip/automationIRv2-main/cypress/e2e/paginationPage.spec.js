const {pagination} = require("../support/pageObjectModel/pagination")
const {propertyObj} = require("../support/pageObjectModel/addProperty")

describe("Pagination Test", () => {
    beforeEach("login",() => {
        propertyObj.login()
        propertyObj.navProperty()
    })

        it("Should count the number of items on the current page based on selection", () => {   
          pagination.setPageLimit5()
        })

        it("Should count the number of items on the current page based on selection", () => {
           pagination.setPagelimit10()
          })

        it("Should count the number of items on the current page based on selection", () => {
          pagination.setPagelimit15()
        })

        it("Should count the number of items on the current page based on selection", () => {
          pagination.setPagelimit20()
        })

        it("Should verify if the Next button is enabled in case of multiple pages" , () => {  
          pagination.nextEnabled()
        })

        it("Should verify if the Next button is disabled in case of a single page" , () => {   
            pagination.nextDisabled()
        })

        it("Should verify if the Previous button is disabled in case of a single page" , () => {   
          pagination.prevDisabled()
        })

        it("Should verify if the Previous button is enabled in case of a multiple page" , () => {   
          pagination.prevEnabled()
        }) 
  })