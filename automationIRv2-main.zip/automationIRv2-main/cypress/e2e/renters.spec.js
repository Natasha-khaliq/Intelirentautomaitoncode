describe("Test Suite for renter flow", ()=>{
    let email = null;
    it('Signup', () => {
        cy.visit('https://staging.internalrent.com/signup?r=cmVudGVy');
        cy.generateEmail().then((generatedEmail) => {
          email = generatedEmail;
          cy.get('[id="Email Address"]').type(email);
        });
        cy.get('#Password').type('C0mplexpass@');
        cy.get('.Signup_createBtn__So7UZ').contains('Create account').click();
      });
    
      it("login", () => {
        cy.visit('https://staging.internalrent.com/login');
        cy.get('[id="Email Address"]').type(email);
        cy.get('#Password').type('C0mplexpass@');
        cy.get('[type="submit"]').contains('Log in').click();
        cy.wait(2000);
      });
      it("renters",()=>{
        //read terms
        cy.get('[type="button"]').contains('Read terms').click()
        cy.get('[type="button"]').contains('I accept').click()
        //select property
        cy.get('[type="button"]').contains('Select a property to start your application').click()
        cy.get('[type="button"]').last().contains('Select property').click()
        cy.get('[type="button"]').contains('Continue with this property').click()
        //rental criteria
        cy.get('[type="button"]').contains('Review rental criteria').click()
        cy.get('[type="button"]').contains('*Open full document here').click()
        cy.get('[type="button"]').contains('I have read the Rental Criteria').click()
        cy.get('[type="button"]').contains("Got it, let's get started!").click()
        //cy.get('[class="StripeDocumentUpload_button__s+r1l"]').click()
        // cy.wait(10000)
        cy.get('.css-hlgwow').click()
        //address
        cy.get('.css-1ir0vnz-option').eq(3).click()
        cy.get('[placeholder="MM DD YYYY"]').click()
        cy.get('[type="button"]').contains('I rent').click()  
        cy.get('[placeholder="Full Name"]').type('khadija zahid')
        cy.get('[name="renterAddress.contactRent"]').type('1000')
        cy.get('[placeholder="(000) 000-0000"]').type('7626235265')
        cy.get('[name="renterAddress.contactEmailAddress"]').type('khadija@gmail.com')
        cy.get('[type="button"]').contains('Got it, next!').click()
        cy.get('[placeholder="Type to search"]').type('123').wait(5000)
        cy.get('.PlacesAutoCompleteComponent_suggestionOptions__1Xb3f').first().click()
        cy.get('[placeholder="MM DD YYYY"]').first().type('02032009')
        cy.get('[placeholder="MM DD YYYY"]').last().type('02032010')
        cy.get('[type="button"]').contains('I do not rent').click()
        cy.get('[type="button"]').contains("Looks good!").click() 
       
        //employment
        cy.get('[type="button"]').first().contains('Employed').click()
        cy.get('[placeholder="Company Name"]').type('Intellirent')
        cy.get('[placeholder="Your role"]').type('Project Manager')
        cy.get('[placeholder="MM DD YYYY"]').type('09092009')
        cy.get('[name="monthlyGrossIncome"]').type('10000')
        cy.get('[name="supervisorName"]').type('Eric')
        cy.get('[placeholder="(000) 000-0000"]').type('8673653343')
        cy.get('[name="supervisorEmailAddress"]').type('kzahid@gmail.com')
        cy.get('[type="submit"]').contains('Looks good!').click()
        cy.get('[type="button"]').contains('I do not have a bank').click()
        // :nth-child(4) > .Button_irBtn__Ozjsb
      })
    })