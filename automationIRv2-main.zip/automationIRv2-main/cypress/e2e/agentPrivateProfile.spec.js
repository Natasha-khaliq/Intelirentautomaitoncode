describe('Test Suite for agent', () => {
    let email = null;
  
    it('Signup', () => {
      cy.visit('https://staging.internalrent.com/signup');
      cy.generateEmail().then((generatedEmail) => {
        email = generatedEmail;
        cy.get('[id="Email Address"]').type(email);
      });
      cy.get('#Password').type('C0mplexpass@');
      cy.get('.Signup_createBtn__So7UZ').contains('Create account').click();
      cy.contains('Private Profile')
    });
  
    it("login", () => {
      cy.visit('https://staging.internalrent.com/login');
      cy.get('[id="Email Address"]').type(email);
      cy.get('#Password').type('C0mplexpass@');
      cy.get('[type="submit"]').contains('Log in').click();
      cy.wait(2000);
    });
    it("Agent Private Profile", ()=>{
      cy.get('.css-hlgwow').first().click()
      cy.get('.css-qr46ko').find('[class=" css-1ir0vnz-option"]').first().contains('Property Manager').click()
      cy.get('[id="First Name"]').type('First')
      cy.get('[placeholder="Last Name"]').type('Last')
      cy.get('[placeholder="Type to search"]').type('123').wait(5000)
      cy.get('.PlacesAutoCompleteComponent_suggestionOptions__1Xb3f').first().click()
      cy.get('.react-tel-input ').type('2345678999')
      cy.wait(5000)
      cy.get('[type="submit"]').contains('Save & Continue').click();
    })
    it("Logout",()=>{
      cy.get('.ProfileIcon_profileName__736E5').click()
      cy.get('.ProfileDropdown_popoverBtn__PYk-A ').contains('Log out').click()
      
    })
  });