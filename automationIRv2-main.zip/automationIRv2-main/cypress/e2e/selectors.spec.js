import Selectors from "./Selectors"
const elements = new  Selectors()
describe('Test Suite for agent', () => {
    let email = null;
  
    it('Signup', () => {
      elements.signupPage.signUpURL
      cy.generateEmail().then((generatedEmail) => {
        email = generatedEmail
        elements.signupPage.emailField.type(email)
      });
      elements.signupPage.passwordField.type('C0mplexpass@');
      elements.signupPage.signupButton
      elements.signupPage.signupBtn.click()
      cy.contains('Private Profile')
    });
  
    it("login", () => {
        elements.loginPage.loginURL;
        elements.loginPage.emailField.type(email)
        elements.loginPage.passwordField.type('C0mplexpass@')
        elements.loginPage.loginButton
        elements.loginPage.loginBtn.click()
    });
    it("Agent Private Profile",()=>{
        //cy.get('.css-13zfbq5-control').first().click().type("Property Manager").type("{enter}")
        elements.AgentPrivProfile.housingProviderCategory.first().click()
        elements.AgentPrivProfile.option.click()
        elements.AgentPrivProfile.firstName.type('First')
        elements.AgentPrivProfile.lastName.type('Last')
        elements.AgentPrivProfile.mailSearch.type('123').wait(5000)
        elements.AgentPrivProfile.mailSearchOpt.first().click()
        elements.AgentPrivProfile.phoneNumberField.type('2345678999')
        cy.wait(5000)
        elements.AgentPrivProfile.saveContinueButton
        elements.AgentPrivProfile.saveContinueBtn.click();
    });
    it("Logout",()=>{
      cy.get('.ProfileIcon_profileName__736E5').click()
      cy.get('.ProfileDropdown_popoverBtn__PYk-A ').contains('Logout').click()
    })
  });
