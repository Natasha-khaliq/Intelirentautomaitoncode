const {rentersObj} = require("../support/PageObjectModel/renters")
describe("Rental Flow",()=>{
    it("Verify renters can signup successfully",()=>{
      rentersObj.signup()
    })
    it("Verify renters can Login successfully",()=>{
        rentersObj.login()
    })
    it("Verify that renters can read Terms",()=>{
        rentersObj.readTerms()
    })
    it("Verify that renters can select property",()=>{
        rentersObj.selectProperty()
    })
    it("Verify that renters can read rental criteria",()=>{
        rentersObj.rentalCriteria()
    })
    it("Check Dropdown in navigation is working",()=>{
        rentersObj.navigation()
    })
    it("Verify that renters can prior and present address successfully",()=>{
        rentersObj.address()
    })
    it("Verify that renters can add employments details",()=>{
        rentersObj.employment()
    })
  })